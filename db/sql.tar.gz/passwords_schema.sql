-- MySQL dump 10.13  Distrib 5.6.17, for Linux (x86_64)
--
-- Host: localhost    Database: passwords
-- ------------------------------------------------------
-- Server version	5.6.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `COCA_wordlist`
--

DROP TABLE IF EXISTS `COCA_wordlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `COCA_wordlist` (
  `freq` int(11) DEFAULT NULL,
  `word` varchar(45) CHARACTER SET latin1 NOT NULL,
  `PoS` varchar(45) CHARACTER SET latin1 NOT NULL,
  `# texts` int(11) DEFAULT NULL,
  PRIMARY KEY (`PoS`,`word`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bigrams`
--

DROP TABLE IF EXISTS `bigrams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bigrams` (
  `freq` int(11) DEFAULT NULL,
  `word1` varchar(45) CHARACTER SET latin1 NOT NULL,
  `word2` varchar(45) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`word2`,`word1`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bnc`
--

DROP TABLE IF EXISTS `bnc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bnc` (
  `frequency` int(11) NOT NULL,
  `word` varchar(80) NOT NULL,
  `PoS` varchar(20) NOT NULL,
  `occurences` int(11) NOT NULL,
  PRIMARY KEY (`word`,`PoS`),
  UNIQUE KEY `word` (`word`,`PoS`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cities150000`
--

DROP TABLE IF EXISTS `cities150000`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cities150000` (
  `geo_id` int(11) unsigned NOT NULL,
  `geo_name` varchar(200) NOT NULL DEFAULT '',
  `geo_ansiname` varchar(200) NOT NULL DEFAULT '',
  `geo_alternate_names` varchar(2000) NOT NULL DEFAULT '',
  `geo_latitude` double(11,7) NOT NULL DEFAULT '0.0000000',
  `geo_longitude` double(11,7) NOT NULL DEFAULT '0.0000000',
  `geo_country_code` char(2) DEFAULT NULL,
  `geo_population` bigint(11) DEFAULT '0',
  `geo_timezone` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`geo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dictionary`
--

DROP TABLE IF EXISTS `dictionary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dictionary` (
  `dict_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dictset_id` tinyint(3) unsigned NOT NULL,
  `dict_text` varchar(60) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`dict_id`),
  UNIQUE KEY `dict_id_UNIQUE` (`dict_id`),
  KEY `fk_dictionary_1` (`dictset_id`),
  KEY `index4` (`dict_text`)
) ENGINE=InnoDB AUTO_INCREMENT=15197273 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table for storing the actual dictionaries in.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dictionary_set`
--

DROP TABLE IF EXISTS `dictionary_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dictionary_set` (
  `dictset_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `dictset_name` tinytext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`dictset_id`),
  UNIQUE KEY `dictset_id_UNIQUE` (`dictset_id`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Table for storing the names/ids of different dictionaries.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `only_no_sets`
--

DROP TABLE IF EXISTS `only_no_sets`;
/*!50001 DROP VIEW IF EXISTS `only_no_sets`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `only_no_sets` (
  `pass_id` tinyint NOT NULL,
  `pass_txt` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `only_with_sets`
--

DROP TABLE IF EXISTS `only_with_sets`;
/*!50001 DROP VIEW IF EXISTS `only_with_sets`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `only_with_sets` (
  `pass_id` tinyint NOT NULL,
  `pass_txt` tinyint NOT NULL,
  `set_id` tinyint NOT NULL,
  `s_index` tinyint NOT NULL,
  `e_index` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `overall_non_filtered`
--

DROP TABLE IF EXISTS `overall_non_filtered`;
/*!50001 DROP VIEW IF EXISTS `overall_non_filtered`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `overall_non_filtered` (
  `pass_id` tinyint NOT NULL,
  `pass_txt` tinyint NOT NULL,
  `set_pw` tinyint NOT NULL,
  `s_index` tinyint NOT NULL,
  `e_index` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `password_set`
--

DROP TABLE IF EXISTS `password_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_set` (
  `pwset_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `pwset_name` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `max_pass_length` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`pwset_id`),
  UNIQUE KEY `pwset_id_UNIQUE` (`pwset_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Table for storing the names/ids of different password sets.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `passwords`
--

DROP TABLE IF EXISTS `passwords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `passwords` (
  `pass_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pwset_id` tinyint(3) unsigned NOT NULL,
  `pass_text` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`pass_id`),
  UNIQUE KEY `pass_id_UNIQUE` (`pass_id`),
  KEY `fk_passwords_1` (`pwset_id`),
  KEY `index5` (`pass_text`),
  KEY `set_text` (`pwset_id`,`pass_text`)
) ENGINE=InnoDB AUTO_INCREMENT=32584477 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=1 COMMENT='Table for storing the actual passwords in.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sentiwordnet`
--

DROP TABLE IF EXISTS `sentiwordnet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sentiwordnet` (
  `POS` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ID` int(11) DEFAULT NULL,
  `PosScore` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NegScore` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SynsetTerms` text COLLATE utf8_unicode_ci,
  `Gloss` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `set_contains`
--

DROP TABLE IF EXISTS `set_contains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `set_contains` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `set_id` int(10) unsigned NOT NULL,
  `dict_id` int(10) unsigned NOT NULL,
  `s_index` tinyint(3) unsigned NOT NULL,
  `e_index` tinyint(3) unsigned NOT NULL,
  `synset` int(11) DEFAULT NULL,
  `sentiment` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pos` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_set_contains_2` (`dict_id`),
  KEY `set_id_index` (`set_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Relation between a set, and the dictionary words and indices';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sets`
--

DROP TABLE IF EXISTS `sets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sets` (
  `set_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pass_id` int(10) unsigned NOT NULL,
  `set_pw` tinytext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`set_id`),
  KEY `fk_sets_1` (`pass_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Holds possible solutions for a password.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trigrams`
--

DROP TABLE IF EXISTS `trigrams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trigrams` (
  `freq` int(11) DEFAULT NULL,
  `word1` varchar(45) CHARACTER SET latin1 NOT NULL,
  `word2` varchar(45) CHARACTER SET latin1 NOT NULL,
  `word3` varchar(45) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`word1`,`word2`,`word3`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `words_per_pwd`
--

DROP TABLE IF EXISTS `words_per_pwd`;
/*!50001 DROP VIEW IF EXISTS `words_per_pwd`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `words_per_pwd` (
  `pass_id` tinyint NOT NULL,
  `set_id` tinyint NOT NULL,
  `set_pwd` tinyint NOT NULL,
  `word_id` tinyint NOT NULL,
  `word` tinyint NOT NULL,
  `dictset_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `only_no_sets`
--

/*!50001 DROP TABLE IF EXISTS `only_no_sets`*/;
/*!50001 DROP VIEW IF EXISTS `only_no_sets`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `only_no_sets` AS select `passwords`.`pass_id` AS `pass_id`,`passwords`.`pass_text` AS `pass_txt` from (`passwords` left join `sets` on((`sets`.`pass_id` = `passwords`.`pass_id`))) where isnull(`sets`.`pass_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `only_with_sets`
--

/*!50001 DROP TABLE IF EXISTS `only_with_sets`*/;
/*!50001 DROP VIEW IF EXISTS `only_with_sets`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `only_with_sets` AS select `passwords`.`pass_id` AS `pass_id`,`passwords`.`pass_text` AS `pass_txt`,`sets`.`set_id` AS `set_id`,`set_contains`.`s_index` AS `s_index`,`set_contains`.`e_index` AS `e_index` from (((`set_contains` left join `sets` on((`set_contains`.`set_id` = `sets`.`set_id`))) left join `dictionary` on((`set_contains`.`dict_id` = `dictionary`.`dict_id`))) left join `passwords` on((`sets`.`pass_id` = `passwords`.`pass_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `overall_non_filtered`
--

/*!50001 DROP TABLE IF EXISTS `overall_non_filtered`*/;
/*!50001 DROP VIEW IF EXISTS `overall_non_filtered`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `overall_non_filtered` AS select `passwords`.`pass_id` AS `pass_id`,`passwords`.`pass_text` AS `pass_txt`,`sets`.`set_pw` AS `set_pw`,`set_contains`.`s_index` AS `s_index`,`set_contains`.`e_index` AS `e_index` from ((`passwords` left join `sets` on((`sets`.`pass_id` = `passwords`.`pass_id`))) left join `set_contains` on((`set_contains`.`set_id` = `sets`.`set_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `words_per_pwd`
--

/*!50001 DROP TABLE IF EXISTS `words_per_pwd`*/;
/*!50001 DROP VIEW IF EXISTS `words_per_pwd`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `words_per_pwd` AS select `sets`.`pass_id` AS `pass_id`,`sets`.`set_id` AS `set_id`,`sets`.`set_pw` AS `set_pwd`,`dictionary`.`dict_id` AS `word_id`,`dictionary`.`dict_text` AS `word`,`dictionary`.`dictset_id` AS `dictset_id` from ((`set_contains` left join `sets` on((`set_contains`.`set_id` = `sets`.`set_id`))) left join `dictionary` on((`set_contains`.`dict_id` = `dictionary`.`dict_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-05-21 20:22:34
